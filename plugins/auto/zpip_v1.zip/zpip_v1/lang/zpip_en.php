<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'adapte_de' => 'adapted from',

	// B

	// C
	'conception_graphique_par' => 'Graphic design (c)',
	'commentaire' => 'comment',
	'commentaires' => 'comments',

	// D
	'date_forum' => '@date@ at @heure@',

	// I

	// L
	'lire_la_suite' => 'Read more',
	'lire_la_suite_de' => ' of ',

	// M

	// P
	'personaliser_nav' => 'Customize this menu',

	// R

	// S
	'sous_licence' => 'under License',

	// T

	// V

	// Z
	'zapl_loading' => 'Loading...',
	'zapl_reload_off' => 'Click here if this page remains empty (or activate javascript in your browser)',
);

?>
