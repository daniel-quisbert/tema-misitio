<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A
	'adapte_de' => 'adapt&eacute; de',
	// B

	// C
	'conception_graphique_par' => 'Habillage visuel &copy;',
	'commentaire' => 'commentaire',
	'commentaires' => 'commentaires',

	// D
	'date_forum' => 'Le @date@ &agrave; @heure@',

	// I

	// L
	'lire_la_suite' => 'Lire la suite',
	'lire_la_suite_de' => ' de ',

	// M

	// P
	'personaliser_nav' => 'Personnaliser ce menu',

	// R

	// S
	'sous_licence' => 'sous Licence',

	// T

	// V

	// Z
	'zapl_loading' => 'Chargement en cours...',
	'zapl_reload_off' => 'Cliquer ici si la page reste incompl&egrave;te (ou activer le javascript dans votre navigateur)',
);

?>
