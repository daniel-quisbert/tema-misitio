<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// Fichier source, a modifier dans svn://zone.spip.org/spip-zone/_plugins_/_stable_/acces_restreint/lang/
if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// A

	// B

	// C

// C
	'conception_graphique_par' => 'Design (c)',
	'commentaire' => 'coment&aacute;rio',
	'commentaires' => 'coment&aacute;rios',

	// D

	// I

	// L
	'lire_la_suite' => 'l&ecirc; mais',
	'lire_la_suite_de' => ' sobre ',

	// M

	// P
	'personaliser_nav' => 'personalisar este menu',

	// R

	// S
	'sous_licence' => 'sob licença',

	// T

	// V

	// Z
);

?>
